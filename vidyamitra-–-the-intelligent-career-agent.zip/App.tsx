
import React, { useState, useEffect } from 'react';
import { 
  LayoutDashboard, 
  FileText, 
  Map, 
  Trophy, 
  Mic2, 
  Briefcase, 
  Bell, 
  Settings,
  LogOut,
  ChevronRight,
  TrendingUp,
  Target,
  BrainCircuit,
  LineChart,
  Loader2,
  Key,
  ShieldCheck,
  UserCircle,
  Cpu
} from 'lucide-react';
import { AppSection, UserProfile } from './types';
import Dashboard from './components/Dashboard';
import ResumeModule from './components/ResumeModule';
import RoadmapModule from './components/RoadmapModule';
import QuizModule from './components/QuizModule';
import InterviewModule from './components/InterviewModule';
import JobModule from './components/JobModule';
import ProgressModule from './components/ProgressModule';
import Auth from './components/Auth';
import { db } from './supabaseService';

declare global {
  interface AIStudio {
    hasSelectedApiKey: () => Promise<boolean>;
    openSelectKey: () => Promise<void>;
  }

  interface Window {
    // Make aistudio optional to avoid modifier mismatch errors with existing declarations
    aistudio?: AIStudio;
  }
}

const App: React.FC = () => {
  const [isInitializing, setIsInitializing] = useState(true);
  const [activeSection, setActiveSection] = useState<AppSection>(AppSection.DASHBOARD);
  const [hasPersonalKey, setHasPersonalKey] = useState(false);
  const [user, setUser] = useState<UserProfile>({
    id: "",
    name: "",
    email: "",
    targetRole: "",
    skills: [],
    resumeText: "",
    isLoggedIn: false 
  });

  const navigation = [
    { id: AppSection.DASHBOARD, label: 'Control Center', icon: LayoutDashboard },
    { id: AppSection.RESUME, label: 'Resume AI', icon: FileText },
    { id: AppSection.ROADMAP, label: 'Skill Pathways', icon: Map },
    { id: AppSection.QUIZ, label: 'Adaptive Quiz', icon: BrainCircuit },
    { id: AppSection.INTERVIEW, label: 'Mock Interview', icon: Mic2 },
    { id: AppSection.PROGRESS, label: 'Performance', icon: LineChart },
    { id: AppSection.JOBS, label: 'Opportunities', icon: Briefcase },
  ];

  useEffect(() => {
    checkApiKey();
    const savedUserId = localStorage.getItem('vm_userId');
    if (savedUserId) {
      db.getProfile(savedUserId).then(profile => {
        if (profile) {
          db.getLatestResume(savedUserId).then(resume => {
            setUser({ 
              ...profile, 
              isLoggedIn: true, 
              resumeText: resume?.content || "" 
            });
            setIsInitializing(false);
          });
        } else {
          setIsInitializing(false);
        }
      }).catch(() => setIsInitializing(false));
    } else {
      setIsInitializing(false);
    }
  }, []);

  const checkApiKey = async () => {
    if (window.aistudio) {
      const hasKey = await window.aistudio.hasSelectedApiKey();
      setHasPersonalKey(hasKey);
    }
  };

  const handleSelectKey = async () => {
    if (window.aistudio) {
      await window.aistudio.openSelectKey();
      setHasPersonalKey(true);
    }
  };

  const handleLogin = async (loginData: Partial<UserProfile>) => {
    const freshUser: UserProfile = {
      id: loginData.id || "",
      name: loginData.name || "",
      email: loginData.email || "",
      targetRole: loginData.targetRole || "",
      skills: loginData.skills || [],
      resumeText: loginData.resumeText || "",
      isLoggedIn: true
    };
    
    setUser(freshUser);
    const saved = await db.saveProfile(freshUser);
    localStorage.setItem('vm_userId', saved.id);
    
    const resume = await db.getLatestResume(saved.id);
    if (resume) {
      setUser(prev => ({ ...prev, id: saved.id, resumeText: resume.content }));
    }
    
    setActiveSection(AppSection.DASHBOARD);
  };

  const handleLogout = () => {
    localStorage.removeItem('vm_userId');
    setUser({
      id: "",
      name: "",
      email: "",
      targetRole: "",
      skills: [],
      resumeText: "",
      isLoggedIn: false
    });
  };

  const updateProfile = async (updates: Partial<UserProfile>) => {
    const updatedUser = { ...user, ...updates };
    setUser(updatedUser);
    if (user.id) {
      await db.saveProfile(updatedUser);
    }
  };

  const navigateTo = (section: AppSection) => {
    setActiveSection(section);
  };

  if (isInitializing) {
    return (
      <div className="min-h-screen bg-white flex flex-col items-center justify-center">
        <div className="bg-indigo-600 p-5 rounded-[2.5rem] shadow-2xl shadow-indigo-200 animate-float mb-8">
          <BrainCircuit className="text-white w-12 h-12" />
        </div>
        <div className="flex flex-col items-center gap-3">
           <Loader2 className="w-6 h-6 text-indigo-500 animate-spin" />
           <p className="text-slate-400 font-bold tracking-widest text-[10px] uppercase">Booting Career Intelligence</p>
        </div>
      </div>
    );
  }

  if (!user.isLoggedIn) {
    return <Auth onLogin={handleLogin} />;
  }

  const renderContent = () => {
    switch (activeSection) {
      case AppSection.DASHBOARD: return <Dashboard user={user} onNavigate={navigateTo} />;
      case AppSection.RESUME: return <ResumeModule user={user} setUser={updateProfile} />;
      case AppSection.ROADMAP: return <RoadmapModule user={user} />;
      case AppSection.QUIZ: return <QuizModule user={user} />;
      case AppSection.INTERVIEW: return <InterviewModule user={user} />;
      case AppSection.PROGRESS: return <ProgressModule user={user} />;
      case AppSection.JOBS: return <JobModule user={user} onGenerateRoadmap={(role) => {
        updateProfile({ targetRole: role });
        setActiveSection(AppSection.ROADMAP);
      }} />;
      default: return <Dashboard user={user} onNavigate={navigateTo} />;
    }
  };

  return (
    <div className="flex min-h-screen">
      {/* Sleek Sidebar */}
      <aside className="w-[300px] bg-white border-r border-slate-100 hidden xl:flex flex-col sticky top-0 h-screen z-30">
        <div className="p-10 flex flex-col h-full">
          {/* Logo Section */}
          <div className="flex items-center gap-4 mb-14 shrink-0 px-2 cursor-pointer group" onClick={() => setActiveSection(AppSection.DASHBOARD)}>
            <div className="bg-indigo-600 p-3 rounded-2xl shadow-xl shadow-indigo-100 group-hover:scale-110 transition-all duration-500">
              <Cpu className="text-white w-7 h-7" />
            </div>
            <div>
               <h1 className="text-2xl font-black text-slate-900 leading-none tracking-tight">VidyaMitra</h1>
               <p className="text-[10px] font-black text-indigo-600 uppercase tracking-widest mt-1">AI Career Agent</p>
            </div>
          </div>
          
          {/* Enhanced Navigation */}
          <nav className="space-y-2 overflow-y-auto flex-1 scrollbar-hide">
            <p className="px-4 text-[11px] font-black uppercase tracking-[0.25em] text-slate-400 mb-6">Capabilities</p>
            {navigation.map((item) => {
              const Icon = item.icon;
              const isActive = activeSection === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => setActiveSection(item.id)}
                  className={`w-full flex items-center gap-4 px-5 py-4 text-[14px] font-bold rounded-2xl transition-all duration-400 group ${
                    isActive
                      ? 'nav-active'
                      : 'text-slate-500 hover:bg-slate-50 hover:text-slate-900'
                  }`}
                >
                  <Icon className={`w-5 h-5 transition-colors ${isActive ? 'text-white' : 'text-slate-400 group-hover:text-indigo-600'}`} />
                  {item.label}
                  {isActive && <div className="ml-auto w-1.5 h-1.5 bg-white rounded-full" />}
                </button>
              );
            })}
          </nav>

          {/* User Footer with Subtle Integration */}
          <div className="mt-10 pt-8 border-t border-slate-50 shrink-0">
            <div className="flex items-center justify-between mb-8 p-1">
               <div className="flex items-center gap-4 overflow-hidden">
                  <div className="w-12 h-12 rounded-2xl bg-indigo-50 border border-indigo-100 flex items-center justify-center text-indigo-600 font-bold shadow-sm">
                    {user.name ? user.name.split(' ').map(n => n[0]).join('').toUpperCase() : <UserCircle />}
                  </div>
                  <div className="overflow-hidden">
                    <p className="text-[15px] font-black text-slate-900 truncate tracking-tight">{user.name || 'User'}</p>
                    <p className="text-[10px] text-slate-400 truncate font-bold uppercase tracking-wider">Professional Tier</p>
                  </div>
               </div>
               <button 
                 onClick={handleSelectKey}
                 className={`w-10 h-10 rounded-xl border flex items-center justify-center transition-all ${hasPersonalKey ? 'bg-emerald-50 border-emerald-100 text-emerald-600' : 'bg-slate-50 border-slate-100 text-slate-400 hover:text-indigo-600'}`}
                 title="AI Infrastructure Settings"
               >
                 <Settings className="w-4 h-4" />
               </button>
            </div>
            
            <button 
              onClick={handleLogout}
              className="w-full flex items-center justify-center gap-3 py-4 bg-slate-50 text-slate-600 hover:bg-rose-50 hover:text-rose-600 rounded-2xl text-sm font-black transition-all border border-transparent hover:border-rose-100"
            >
              <LogOut className="w-4 h-4" />
              Terminate Session
            </button>
          </div>
        </div>
      </aside>
      
      {/* Main Experience Area */}
      <main className="flex-1 flex flex-col h-screen overflow-hidden bg-[#fafbfc]">
        <header className="h-24 bg-white/70 backdrop-blur-xl border-b border-slate-100 flex items-center justify-between px-12 sticky top-0 z-20">
          <div className="flex items-center gap-6">
            <div className="h-10 w-[2px] bg-indigo-600/10 rounded-full hidden lg:block"></div>
            <div>
               <h2 className="text-2xl font-black text-slate-900 tracking-tight">
                {navigation.find(n => n.id === activeSection)?.label}
               </h2>
               <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest mt-0.5">VidyaMitra Intellect-v1</p>
            </div>
          </div>
          
          <div className="flex items-center gap-5">
            <div className="hidden md:flex flex-col items-end mr-4">
               <p className="text-[11px] font-black text-slate-900">Infrastructure Status</p>
               <div className="flex items-center gap-1.5 mt-1">
                  <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></div>
                  <p className="text-[10px] font-bold text-emerald-600 uppercase tracking-tighter">AI Core Online</p>
               </div>
            </div>
            
            <button className="text-slate-400 hover:text-indigo-600 transition-all p-3.5 rounded-2xl bg-slate-100/50 hover:bg-indigo-50 border border-transparent hover:border-indigo-100 relative group">
              <Bell className="w-5 h-5" />
              <span className="absolute top-3.5 right-3.5 w-2 h-2 bg-rose-500 rounded-full border-2 border-white"></span>
            </button>
            
            <div className="h-10 w-[1px] bg-slate-100 mx-1"></div>
            
            <div className="flex items-center gap-3 px-5 py-3 bg-white premium-shadow rounded-2xl border border-slate-100">
               <ShieldCheck className="w-5 h-5 text-indigo-500" />
               <span className="text-[11px] font-black text-slate-800 uppercase tracking-widest">Profile Secured</span>
            </div>
          </div>
        </header>

        <div className="flex-1 overflow-y-auto p-12 scroll-smooth">
          <div className="max-w-[1400px] mx-auto animate-fade-up">
            {renderContent()}
          </div>
        </div>
      </main>
    </div>
  );
};

export default App;
