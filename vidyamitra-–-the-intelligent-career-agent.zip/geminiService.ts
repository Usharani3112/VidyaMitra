
import { GoogleGenAI, Type, Modality } from "@google/genai";
import { ResumeAnalysis, LearningRoadmap, QuizQuestion, InterviewRound } from "./types";

export interface ResumeInput {
  text?: string;
  file?: {
    data: string;
    mimeType: string;
  };
}

// Helper to handle mandatory API key re-selection on specific errors
const handleApiError = async (error: any) => {
  if (error.message?.includes("Requested entity was not found")) {
    if (window.aistudio) {
      await window.aistudio.openSelectKey();
    }
  }
  throw error;
};

export const analyzeResume = async (resume: ResumeInput, targetRole: string): Promise<ResumeAnalysis> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  const parts: any[] = [];
  
  if (resume.text) {
    parts.push({ text: `Resume Text Content: ${resume.text}` });
  }
  
  if (resume.file) {
    parts.push({
      inlineData: {
        data: resume.file.data,
        mimeType: resume.file.mimeType
      }
    });
  }

  parts.push({ text: `TASK: Conduct a comprehensive ATS analysis of this resume for the specific role: "${targetRole}".` });

  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-pro-preview",
      contents: { parts },
      config: {
        seed: 42,
        systemInstruction: `You are an elite Technical Recruiter and ATS Optimization Expert.
        
        CRITICAL INSTRUCTIONS:
        1. DETERMINISM: For the same content and role, you must return the same score.
        2. PROJECT-BASED SKILL EXTRACTION: If technologies (like Python, CNN, TensorFlow, OpenCV) are mentioned in projects, THEY ARE PRESENT.
        3. ATS SCORING: Provide a consistent score (0-100) based on keyword density, role relevance, and project impact.
        4. BE HONEST: If a skill is clearly in the resume, it must be in 'extractedSkills' and 'strengths'.`,
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            atsScore: { type: Type.NUMBER },
            extractedSkills: { type: Type.ARRAY, items: { type: Type.STRING } },
            missingSkills: { type: Type.ARRAY, items: { type: Type.STRING } },
            strengths: { type: Type.ARRAY, items: { type: Type.STRING } },
            improvements: { type: Type.ARRAY, items: { type: Type.STRING } },
          },
          required: ["atsScore", "extractedSkills", "missingSkills", "strengths", "improvements"],
        }
      }
    });

    const jsonStr = response.text || "{}";
    return JSON.parse(jsonStr);
  } catch (error) {
    return handleApiError(error);
  }
};

export const generateRoadmap = async (currentSkills: string[], targetRole: string): Promise<LearningRoadmap> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-pro-preview",
      contents: `Skills: [${currentSkills.join(', ')}]\nTarget Role: ${targetRole}`,
      config: {
        seed: 42,
        systemInstruction: "Generate a detailed learning roadmap including duration and YouTube search queries for resources.",
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            title: { type: Type.STRING },
            duration: { type: Type.STRING },
            modules: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  name: { type: Type.STRING },
                  description: { type: Type.STRING },
                  resources: { type: Type.ARRAY, items: { type: Type.STRING } }
                },
                required: ["name", "description", "resources"]
              }
            }
          },
          required: ["title", "duration", "modules"]
        }
      }
    });

    const jsonStr = response.text || "{}";
    const result = JSON.parse(jsonStr);
    return { ...result, target_role: targetRole };
  } catch (error) {
    return handleApiError(error);
  }
};

export const generateQuiz = async (topic: string, level: string): Promise<QuizQuestion[]> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: `Generate a 5-question multiple choice quiz about ${topic} at ${level} level.`,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              id: { type: Type.STRING },
              question: { type: Type.STRING },
              options: { type: Type.ARRAY, items: { type: Type.STRING } },
              correctAnswer: { type: Type.NUMBER, description: "Index of the correct option (0-3)" },
              explanation: { type: Type.STRING }
            },
            required: ["id", "question", "options", "correctAnswer", "explanation"]
          }
        }
      }
    });

    const jsonStr = response.text || "[]";
    return JSON.parse(jsonStr);
  } catch (error) {
    return handleApiError(error);
  }
};

export const generateInitialInterviewQuestion = async (role: string, round: InterviewRound): Promise<string> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: `Act as a supportive interviewer for a junior position. Generate a very simple and basic opening question for a ${round} interview for the position of ${role}.`,
      config: {
        systemInstruction: "You are a friendly interviewer. Ask a simple, introductory question. Avoid any complexity or difficult technical scenarios. Only return the question string.",
      }
    });
    return response.text || "Can you tell me a little bit about yourself and why you like this field?";
  } catch (error) {
    return handleApiError(error);
  }
};

export interface InterviewEvaluation {
  score: number;
  feedback: string;
  suggestion: string;
  nextQuestion: string;
}

export const getInterviewFeedback = async (question: string, answer: string, role: string, round: InterviewRound, isLastQuestion: boolean): Promise<InterviewEvaluation> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-pro-preview",
      contents: `Round: ${round}\nQuestion: ${question}\nUser Answer: ${answer}`,
      config: {
        systemInstruction: `Evaluate the user's answer for the job role: ${role} in a ${round} interview. 
        
        STRICT RULES FOR QUESTIONS:
        1. All questions MUST be very simple, basic, and introductory.
        2. NO complex scenarios, NO architectural deep-dives, NO advanced algorithms.
        3. If 'isLastQuestion' is false, generate a NEW basic question.
        
        ROUND GUIDELINES:
        - Technical Round: Ask simple definitions (e.g., "What is a loop?", "What is a database?") or basic concepts.
        - Managerial Round: Ask simple teamwork questions (e.g., "Do you like working with others?").
        - HR Round: Ask basic background/interest questions (e.g., "What are your hobbies?").`,
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            score: { type: Type.NUMBER, description: "Score from 0 to 100" },
            feedback: { type: Type.STRING, description: "Encouraging and simple feedback" },
            suggestion: { type: Type.STRING, description: "A simple tip to improve" },
            nextQuestion: { type: Type.STRING, description: "A basic, introductory next question" }
          },
          required: ["score", "feedback", "suggestion", "nextQuestion"]
        }
      }
    });

    const jsonStr = response.text || "{}";
    return JSON.parse(jsonStr);
  } catch (error) {
    return handleApiError(error);
  }
};

export const textToSpeech = async (text: string): Promise<string | undefined> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash-preview-tts",
      contents: [{ parts: [{ text: `Speak this naturally as a friendly interviewer: ${text}` }] }],
      config: {
        responseModalities: [Modality.AUDIO],
        speechConfig: {
          voiceConfig: {
            prebuiltVoiceConfig: { voiceName: 'Kore' },
          },
        },
      },
    });
    return response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
  } catch (error) {
    if (error.message?.includes("Requested entity was not found")) {
      if (window.aistudio) {
        await window.aistudio.openSelectKey();
      }
    }
    console.error("TTS failed:", error);
    return undefined;
  }
};
