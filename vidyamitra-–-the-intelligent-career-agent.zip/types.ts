
export interface UserProfile {
  id?: string;
  name: string;
  email: string;
  targetRole: string;
  skills: string[];
  resumeText?: string;
  isLoggedIn: boolean;
}

export interface ResumeAnalysis {
  atsScore: number;
  extractedSkills: string[];
  missingSkills: string[];
  strengths: string[];
  improvements: string[];
  hash?: string;
}

export interface LearningRoadmap {
  id?: string;
  title: string;
  duration: string;
  target_role: string;
  created_at?: string;
  modules: {
    name: string;
    description: string;
    resources: string[];
  }[];
}

export interface QuizQuestion {
  id: string;
  question: string;
  options: string[];
  correctAnswer: number;
  explanation: string;
}

export interface QuizResult {
  id: string;
  topic: string;
  score: number;
  total: number;
  difficulty: string;
  date: string;
}

export enum InterviewRound {
  TECHNICAL = 'TECHNICAL',
  MANAGERIAL = 'MANAGERIAL',
  HR = 'HR'
}

export interface InterviewResult {
  id: string;
  role: string;
  round_type: InterviewRound;
  score: number;
  feedback: string;
  passed: boolean;
  date: string;
}

export interface JobRecommendation {
  id: string;
  title: string;
  company: string;
  location: string;
  matchScore: number;
  description: string;
  link: string;
}

export enum AppSection {
  DASHBOARD = 'DASHBOARD',
  RESUME = 'RESUME',
  ROADMAP = 'ROADMAP',
  QUIZ = 'QUIZ',
  INTERVIEW = 'INTERVIEW',
  JOBS = 'JOBS',
  PROGRESS = 'PROGRESS'
}
