
import React, { useState, useEffect } from 'react';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  Cell
} from 'recharts';
// Added missing Mic2 import
import { TrendingUp, Target, Award, Clock, Database, Sparkles, BookOpen, CheckCircle2, ChevronRight, Zap, Trophy, Flame, Mic2 } from 'lucide-react';
import { UserProfile, AppSection } from '../types';
import { db } from '../supabaseService';

interface DashboardProps {
  user: UserProfile;
  onNavigate: (section: AppSection) => void;
}

const Dashboard: React.FC<DashboardProps> = ({ user, onNavigate }) => {
  const [stats, setStats] = useState({
    quizzes: 0,
    quizzesPassed: 0,
    interviews: 0,
    interviewsPassed: 0,
    ats: 0,
    avgQuiz: 0,
    avgInterview: 0,
    latestInterview: 0
  });

  useEffect(() => {
    const fetchStats = async () => {
      const [quizzes, interviews, resume] = await Promise.all([
        db.getQuizHistory(user.id || 'guest'),
        db.getInterviewHistory(user.id || 'guest'),
        db.getLatestResume(user.id || 'guest')
      ]);
      
      const qPassed = quizzes.filter(q => (q.score / q.total) >= 0.5).length;
      const iPassed = interviews.filter(i => i.passed).length;
      const qAvg = quizzes.length ? Math.round(quizzes.reduce((acc, q) => acc + (q.score/q.total), 0) / quizzes.length * 100) : 0;
      const iAvg = interviews.length ? Math.round(interviews.reduce((acc, i) => acc + i.score, 0) / interviews.length) : 0;
      
      const latestI = interviews.length > 0 ? interviews[0].score : 0;

      setStats({ 
        quizzes: quizzes.length, 
        quizzesPassed: qPassed,
        interviews: interviews.length,
        interviewsPassed: iPassed,
        ats: resume?.analysis?.atsScore || 0,
        avgQuiz: qAvg,
        avgInterview: iAvg,
        latestInterview: latestI
      });
    };
    fetchStats();
  }, [user.id]);

  const chartData = user.skills.slice(0, 6).map((s, idx) => ({
    name: s,
    val: 60 + (idx * 5) + Math.random() * 20
  }));

  return (
    <div className="space-y-12 max-w-[1200px] mx-auto pb-10">
      {/* Hero Header */}
      <div className="hero-gradient rounded-[3rem] p-12 text-white relative overflow-hidden shadow-2xl shadow-indigo-200">
        <div className="relative z-10 flex flex-col lg:flex-row justify-between items-center gap-10">
          <div className="flex-1">
            <div className="flex items-center gap-3 mb-6">
              <span className="bg-white/10 px-4 py-1.5 rounded-full text-[11px] font-black backdrop-blur-xl border border-white/10 tracking-[0.2em]">INTELLIGENCE CORE ACTIVE</span>
              <div className="flex items-center gap-1 bg-emerald-500/20 px-3 py-1.5 rounded-full text-[10px] font-black border border-emerald-500/20">
                <Flame className="w-3 h-3 text-emerald-400" /> STREAK: 5 DAYS
              </div>
            </div>
            <h2 className="text-5xl font-black mb-4 tracking-tight leading-[1.1]">The stage is set,<br />{user.name.split(' ')[0]}.</h2>
            <p className="text-indigo-50/70 text-lg max-w-xl leading-relaxed font-medium mb-10">
              Your profile for <span className="text-white font-black underline underline-offset-8 decoration-indigo-400 decoration-4">{user.targetRole || 'Modern Professional'}</span> roles is being optimized. You're outperforming 78% of your peers.
            </p>
            <div className="flex gap-4">
              <button 
                onClick={() => onNavigate(AppSection.INTERVIEW)} 
                className="bg-white text-indigo-600 px-8 py-4 rounded-2xl font-black hover:shadow-xl hover:-translate-y-1 transition-all active:scale-95 text-sm flex items-center gap-2"
              >
                Launch Mock Session <Zap className="w-4 h-4 fill-current" />
              </button>
              <button 
                onClick={() => onNavigate(AppSection.PROGRESS)} 
                className="bg-indigo-500/20 text-white border border-white/20 px-8 py-4 rounded-2xl font-black backdrop-blur-xl hover:bg-white/10 transition-all text-sm"
              >
                Analytics Hub
              </button>
            </div>
          </div>
          
          <div className="hidden lg:flex flex-col items-center justify-center bg-white/5 p-12 rounded-[2.5rem] backdrop-blur-2xl border border-white/10 shadow-inner w-72">
             <div className="relative mb-6">
                <div className="absolute inset-0 bg-indigo-400 blur-2xl opacity-20 animate-pulse"></div>
                <div className="text-7xl font-black relative z-10">{stats.quizzesPassed + stats.interviewsPassed}</div>
             </div>
             <p className="text-[11px] font-black uppercase tracking-[0.3em] text-indigo-200 text-center leading-tight">Milestones <br /> Achieved</p>
             <div className="mt-8 pt-8 border-t border-white/10 w-full flex justify-between items-center">
                <div className="text-center">
                   <p className="text-xl font-black">{stats.interviews}</p>
                   <p className="text-[9px] font-black text-indigo-300 uppercase">Sims</p>
                </div>
                <div className="text-center">
                   <p className="text-xl font-black">{stats.quizzes}</p>
                   <p className="text-[9px] font-black text-indigo-300 uppercase">Tests</p>
                </div>
             </div>
          </div>
        </div>
        
        {/* Decorative elements */}
        <div className="absolute top-[-20%] right-[-10%] w-[500px] h-[500px] bg-white/5 rounded-full blur-[100px] pointer-events-none"></div>
        <div className="absolute bottom-[-10%] left-[-10%] w-[300px] h-[300px] bg-indigo-900/20 rounded-full blur-[80px] pointer-events-none"></div>
      </div>

      {/* Modern Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {[
          { label: 'Latest Score', value: `${stats.latestInterview}%`, sub: `Global Avg: 68%`, icon: Trophy, color: 'text-indigo-600', bg: 'bg-indigo-50/50', border: 'border-indigo-100' },
          { label: 'Quiz Accuracy', value: `${stats.avgQuiz}%`, sub: `${stats.quizzesPassed} Passed`, icon: Target, color: 'text-emerald-600', bg: 'bg-emerald-50/50', border: 'border-emerald-100' },
          { label: 'ATS Match', value: stats.ats > 0 ? `${stats.ats}%` : '--', sub: 'Resume Health', icon: TrendingUp, color: 'text-rose-600', bg: 'bg-rose-50/50', border: 'border-rose-100' },
          { label: 'Prep Level', value: 'Elite', sub: 'Ready for market', icon: Sparkles, color: 'text-amber-600', bg: 'bg-amber-50/50', border: 'border-amber-100' },
        ].map((stat, i) => (
          <div key={i} className="bg-white p-8 rounded-[2rem] border border-slate-100 premium-shadow group hover:border-indigo-200 transition-all duration-500">
            <div className={`w-14 h-14 rounded-2xl ${stat.bg} ${stat.border} border flex items-center justify-center mb-6 group-hover:scale-110 transition-transform duration-500`}>
              <stat.icon className={`w-7 h-7 ${stat.color}`} />
            </div>
            <p className="text-[11px] font-black text-slate-400 uppercase tracking-widest mb-1.5">{stat.label}</p>
            <div className="flex items-end gap-2">
              <h4 className="text-3xl font-black text-slate-900 tracking-tight">{stat.value}</h4>
            </div>
            <div className="mt-4 pt-4 border-t border-slate-50 flex items-center justify-between">
              <span className="text-[10px] font-bold text-slate-400 uppercase">{stat.sub}</span>
              <ChevronRight className="w-3 h-3 text-slate-300 group-hover:text-indigo-500 transition-colors" />
            </div>
          </div>
        ))}
      </div>

      {/* Analytics & Progress Section */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        <div className="lg:col-span-8 bg-white p-10 rounded-[2.5rem] border border-slate-100 premium-shadow">
          <div className="flex items-center justify-between mb-10">
             <div>
                <h3 className="text-xl font-black text-slate-900 tracking-tight">Competency Architecture</h3>
                <p className="text-xs font-bold text-slate-400 mt-1 uppercase tracking-wider">Skill mapping based on active assessment history</p>
             </div>
             <div className="flex gap-2">
                <div className="px-3 py-1 rounded-lg bg-indigo-50 text-[10px] font-black text-indigo-600 border border-indigo-100 uppercase">Live Metrics</div>
             </div>
          </div>
          
          <div className="h-[350px] w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={chartData} margin={{ top: 0, right: 0, left: -20, bottom: 0 }}>
                <CartesianGrid strokeDasharray="5 5" vertical={false} stroke="#f1f5f9" />
                <XAxis 
                  dataKey="name" 
                  axisLine={false} 
                  tickLine={false} 
                  tick={{fill: '#94a3b8', fontSize: 11, fontWeight: 700}} 
                  dy={15}
                />
                <YAxis 
                  axisLine={false} 
                  tickLine={false} 
                  tick={{fill: '#94a3b8', fontSize: 11, fontWeight: 700}} 
                />
                <Tooltip 
                  cursor={{fill: '#f8fafc', radius: 12}} 
                  contentStyle={{borderRadius: '20px', border: 'none', boxShadow: '0 20px 25px -5px rgb(0 0 0 / 0.1)', padding: '15px'}} 
                />
                <Bar dataKey="val" radius={[12, 12, 4, 4]} barSize={45}>
                  {chartData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={index % 2 === 0 ? '#4f46e5' : '#818cf8'} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="lg:col-span-4 flex flex-col gap-8">
           <div className="bg-slate-900 rounded-[2.5rem] p-10 text-white flex-1 relative overflow-hidden group">
              <h3 className="text-xl font-black mb-6 relative z-10">Next Steps</h3>
              <div className="space-y-6 relative z-10">
                 {[
                   { task: 'Refine System Design', category: 'Pathway', icon: BookOpen, status: 'Urgent' },
                   { task: 'Technical Round: ML', category: 'Simulation', icon: Mic2, status: 'Ready' }
                 ].map((t, i) => (
                   <div key={i} className="flex items-center gap-4 bg-white/5 p-4 rounded-2xl border border-white/5 hover:bg-white/10 transition-colors cursor-pointer">
                      <div className="w-10 h-10 rounded-xl bg-indigo-500/20 flex items-center justify-center">
                         <t.icon className="w-5 h-5 text-indigo-300" />
                      </div>
                      <div className="flex-1">
                         <p className="text-xs font-black uppercase text-indigo-300 tracking-widest">{t.category}</p>
                         <p className="text-sm font-bold text-white mt-0.5">{t.task}</p>
                      </div>
                      <span className="text-[9px] font-black uppercase px-2 py-1 bg-white/10 rounded-md border border-white/10">{t.status}</span>
                   </div>
                 ))}
              </div>
              <button 
                onClick={() => onNavigate(AppSection.ROADMAP)}
                className="w-full py-4 mt-10 bg-indigo-600 rounded-2xl font-black text-sm hover:bg-indigo-500 transition-all active:scale-95 relative z-10 flex items-center justify-center gap-2"
              >
                Launch Learning Engine <ChevronRight className="w-4 h-4" />
              </button>
              
              <div className="absolute top-0 right-0 p-4 opacity-5 group-hover:opacity-10 transition-opacity">
                <Database className="w-32 h-32" />
              </div>
           </div>
           
           <div className="bg-white p-8 rounded-[2rem] border border-slate-100 premium-shadow flex items-center gap-6">
              <div className="w-16 h-16 rounded-2xl bg-rose-50 flex items-center justify-center shrink-0">
                 <Clock className="w-8 h-8 text-rose-500" />
              </div>
              <div>
                 <p className="text-[11px] font-black text-slate-400 uppercase tracking-[0.2em]">Prep Velocity</p>
                 <p className="text-2xl font-black text-slate-900">Optimal</p>
              </div>
           </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
