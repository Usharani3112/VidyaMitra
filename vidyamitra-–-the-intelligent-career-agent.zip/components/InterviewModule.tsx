
import React, { useState, useEffect, useRef } from 'react';
import { Send, Loader2, BrainCircuit, CheckCircle, XCircle, ChevronRight, Lock, Sparkles, User } from 'lucide-react';
import { getInterviewFeedback, textToSpeech, generateInitialInterviewQuestion } from '../geminiService';
import { db } from '../supabaseService';
import { UserProfile, InterviewRound, InterviewResult } from '../types';

interface Message {
  role: 'ai' | 'user';
  text: string;
  feedback?: string;
  suggestion?: string;
}

const InterviewModule: React.FC<{ user: UserProfile }> = ({ user }) => {
  const [isActive, setIsActive] = useState(false);
  const [activeRound, setActiveRound] = useState<InterviewRound>(InterviewRound.TECHNICAL);
  const [messages, setMessages] = useState<Message[]>([]);
  const [currentInput, setCurrentInput] = useState("");
  const [loading, setLoading] = useState(false);
  const [turnCount, setTurnCount] = useState(0);
  const [roundScore, setRoundScore] = useState(0);
  const [roundHistory, setRoundHistory] = useState<Record<string, {passed: boolean, score: number}>>({});
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const QUESTIONS_PER_ROUND = activeRound === InterviewRound.TECHNICAL ? 5 : 4;

  // Fetch history on mount to persist "Passed" status across sessions
  useEffect(() => {
    const loadHistory = async () => {
      const history = await db.getInterviewHistory(user.id || 'guest');
      const historyMap: Record<string, {passed: boolean, score: number}> = {};
      
      // Sort by date to get the latest result for each round type
      const sorted = [...history].sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());
      sorted.forEach(item => {
        historyMap[item.round_type] = { passed: item.passed, score: item.score };
      });
      
      setRoundHistory(historyMap);
    };
    loadHistory();
  }, [user.id]);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, loading]);

  const playAiVoice = async (text: string) => {
    const base64Audio = await textToSpeech(text);
    if (!base64Audio) return;
    const ctx = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
    const binary = atob(base64Audio);
    const bytes = new Uint8Array(binary.length);
    for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
    const dataInt16 = new Int16Array(bytes.buffer);
    const buffer = ctx.createBuffer(1, dataInt16.length, 24000);
    const channelData = buffer.getChannelData(0);
    for (let i = 0; i < dataInt16.length; i++) channelData[i] = dataInt16[i] / 32768.0;
    const source = ctx.createBufferSource();
    source.buffer = buffer;
    source.connect(ctx.destination);
    source.start();
  };

  const startRound = async (round: InterviewRound) => {
    setLoading(true);
    setIsActive(true);
    setActiveRound(round);
    setTurnCount(0);
    setRoundScore(0);
    
    try {
      const firstQuestion = await generateInitialInterviewQuestion(user.targetRole, round);
      const greeting = `Hi! Let's start with something easy. ${firstQuestion}`;
      
      setMessages([{ role: 'ai', text: firstQuestion }]);
      playAiVoice(greeting);
    } catch (err) {
      console.error(err);
      setMessages([{ role: 'ai', text: "I'm having trouble starting the session. Please try again." }]);
    } finally {
      setLoading(false);
    }
  };

  const handleSend = async () => {
    if (!currentInput.trim() || loading) return;
    const userText = currentInput;
    setMessages(prev => [...prev, { role: 'user', text: userText }]);
    setCurrentInput("");
    setLoading(true);

    try {
      const lastQuestion = messages[messages.length - 1].text;
      const isLast = turnCount + 1 >= QUESTIONS_PER_ROUND;
      
      const result = await getInterviewFeedback(lastQuestion, userText, user.targetRole, activeRound, isLast);
      
      const turnScore = Number(result.score) || 0;
      const newTurnCount = turnCount + 1;
      const newScore = roundScore + turnScore;
      
      setTurnCount(newTurnCount);
      setRoundScore(newScore);

      if (newTurnCount < QUESTIONS_PER_ROUND) {
        setMessages(prev => [
          ...prev, 
          { 
            role: 'ai', 
            text: result.nextQuestion, 
            feedback: result.feedback,
            suggestion: result.suggestion
          }
        ]);
        playAiVoice(`${result.feedback}. ${result.nextQuestion}`);
      } else {
        // Round Finished
        const avg = Math.round(newScore / QUESTIONS_PER_ROUND);
        const passed = avg >= 60;
        
        const timestamp = new Date().toISOString();
        await db.saveInterviewResult(user.id || 'guest', {
          role: user.targetRole,
          round_type: activeRound,
          score: avg,
          feedback: `Great job! You finished this introductory round with a score of ${avg}%. ${passed ? 'You passed!' : 'Try again soon!'}`,
          passed,
          date: timestamp
        });

        setRoundHistory(prev => ({ ...prev, [activeRound]: { passed, score: avg } }));
        setIsActive(false);
      }
    } catch (e) { 
      console.error(e); 
      setMessages(prev => [...prev, { role: 'ai', text: "Sorry, I encountered an error. Could you repeat that?" }]);
    } finally { 
      setLoading(false); 
    }
  };

  return (
    <div className="max-w-4xl mx-auto space-y-8 pb-20">
      <div className="grid grid-cols-3 gap-4">
        {[InterviewRound.TECHNICAL, InterviewRound.MANAGERIAL, InterviewRound.HR].map((r, i) => {
          const status = roundHistory[r];
          const isUnlocked = i === 0 || roundHistory[Object.values(InterviewRound)[i-1]]?.passed;
          return (
            <div key={r} className={`p-4 rounded-2xl border-2 transition-all ${status?.passed ? 'bg-emerald-50 border-emerald-200 shadow-sm' : status?.passed === false ? 'bg-red-50 border-red-200' : 'bg-white border-slate-100 shadow-sm'}`}>
              <div className="flex items-center justify-between mb-2">
                <span className="text-[10px] font-black uppercase text-slate-400 tracking-widest">{r}</span>
                {status?.passed ? <CheckCircle className="w-4 h-4 text-emerald-500" /> : status?.passed === false ? <XCircle className="w-4 h-4 text-red-500" /> : isUnlocked ? <ChevronRight className="w-4 h-4 text-indigo-400" /> : <Lock className="w-3 h-3 text-slate-300" />}
              </div>
              <p className="text-sm font-bold text-slate-900">{status ? `${status.score}%` : isUnlocked ? 'Ready' : 'Locked'}</p>
            </div>
          );
        })}
      </div>

      {!isActive ? (
        <div className="bg-white p-12 rounded-[2.5rem] border border-slate-200 text-center shadow-xl">
          <div className="w-20 h-20 bg-indigo-50 rounded-3xl flex items-center justify-center mx-auto mb-8 shadow-inner">
            <BrainCircuit className="w-10 h-10 text-indigo-600" />
          </div>
          <h2 className="text-3xl font-black text-slate-900 mb-2">Mock Interview Suite</h2>
          <p className="text-slate-500 mb-10 font-medium italic">Your progress is automatically saved to your cloud profile.</p>
          
          <div className="flex flex-col gap-4 max-w-xs mx-auto">
            {!roundHistory[InterviewRound.TECHNICAL] && (
              <button onClick={() => startRound(InterviewRound.TECHNICAL)} className="bg-indigo-600 text-white py-4 rounded-2xl font-bold shadow-lg shadow-indigo-100 hover:bg-indigo-700 transition-all active:scale-95">Start Technical Basics</button>
            )}
            {roundHistory[InterviewRound.TECHNICAL]?.passed && !roundHistory[InterviewRound.MANAGERIAL] && (
              <button onClick={() => startRound(InterviewRound.MANAGERIAL)} className="bg-indigo-600 text-white py-4 rounded-2xl font-bold shadow-lg shadow-indigo-100 hover:bg-indigo-700 transition-all active:scale-95">Start Simple Teamwork Round</button>
            )}
            {roundHistory[InterviewRound.MANAGERIAL]?.passed && !roundHistory[InterviewRound.HR] && (
              <button onClick={() => startRound(InterviewRound.HR)} className="bg-indigo-600 text-white py-4 rounded-2xl font-bold shadow-lg shadow-indigo-100 hover:bg-indigo-700 transition-all active:scale-95">Start Basic HR Intro</button>
            )}
            {/* Retry option for failed rounds */}
            {Object.entries(roundHistory).map(([round, data]) => !data.passed && (
              <button key={round} onClick={() => startRound(round as InterviewRound)} className="bg-slate-800 text-white py-4 rounded-2xl font-bold shadow-lg shadow-slate-100 hover:bg-slate-900 transition-all active:scale-95">Retry {round} Round</button>
            ))}
            
            {(roundHistory[InterviewRound.TECHNICAL] || roundHistory[InterviewRound.MANAGERIAL] || roundHistory[InterviewRound.HR]) && (
              <button onClick={() => { setRoundHistory({}); setMessages([]); }} className="text-slate-400 font-bold text-xs mt-4 hover:text-rose-500 transition-colors">Clear Local View</button>
            )}
          </div>
        </div>
      ) : (
        <div className="bg-white rounded-[2.5rem] border border-slate-200 shadow-2xl overflow-hidden h-[700px] flex flex-col animate-in slide-in-from-bottom-8 duration-500">
          <div className="p-6 bg-slate-50/80 border-b flex justify-between items-center backdrop-blur-md">
             <div>
               <div className="flex items-center gap-2 mb-0.5">
                  <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></div>
                  <span className="font-black text-xs uppercase tracking-widest text-slate-400">Live Assessment</span>
               </div>
               <div className="font-bold text-lg text-slate-900">{activeRound} Round</div>
             </div>
             <div className="flex flex-col items-end">
                <div className="text-xs text-indigo-600 font-black px-3 py-1 bg-white rounded-full border border-indigo-100 mb-1 shadow-sm">
                  Turn: {turnCount}/{QUESTIONS_PER_ROUND}
                </div>
             </div>
          </div>
          
          <div className="flex-1 overflow-y-auto p-8 space-y-6 bg-slate-50/30">
            {messages.map((m, i) => (
              <div key={i} className={`flex flex-col ${m.role === 'ai' ? 'items-start' : 'items-end'}`}>
                {m.feedback && (
                  <div className="mb-3 max-w-[85%] bg-indigo-50 border border-indigo-100 rounded-2xl p-4 text-xs animate-in fade-in slide-in-from-top-2">
                    <div className="flex items-center gap-2 text-indigo-700 font-bold mb-2 uppercase tracking-widest text-[10px]">
                      <Sparkles className="w-3 h-3" /> Quick Feedback
                    </div>
                    <p className="text-indigo-900 font-medium mb-2 italic">"{m.feedback}"</p>
                    <div className="pt-2 border-t border-indigo-200/50 text-indigo-600">
                      <strong>Simple Tip:</strong> {m.suggestion}
                    </div>
                  </div>
                )}
                
                <div className={`flex items-start gap-3 group ${m.role === 'ai' ? 'flex-row' : 'flex-row-reverse'}`}>
                  <div className={`w-8 h-8 rounded-full flex items-center justify-center shrink-0 shadow-sm ${m.role === 'ai' ? 'bg-indigo-600 text-white' : 'bg-white border border-slate-200 text-slate-600'}`}>
                    <BrainCircuit className="w-4 h-4" />
                  </div>
                  <div className={`p-5 rounded-2xl text-sm leading-relaxed shadow-sm transition-all ${
                    m.role === 'ai' 
                      ? 'bg-white text-slate-800 rounded-tl-none border border-slate-100 max-w-[85%]' 
                      : 'bg-indigo-600 text-white rounded-tr-none max-w-[85%] font-medium'
                  }`}>
                    {m.text}
                  </div>
                </div>
              </div>
            ))}
            {loading && (
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-full bg-slate-100 flex items-center justify-center">
                  <Loader2 className="w-4 h-4 animate-spin text-indigo-600" />
                </div>
                <div className="bg-white border border-slate-100 p-4 rounded-2xl rounded-tl-none italic text-slate-400 text-xs">
                  Interviewer is listening...
                </div>
              </div>
            )}
            <div ref={messagesEndRef} />
          </div>

          <div className="p-8 border-t bg-white flex gap-4 items-center">
            <div className="flex-1 relative">
              <input 
                type="text" 
                value={currentInput} 
                onChange={(e) => setCurrentInput(e.target.value)} 
                onKeyPress={(e) => e.key === 'Enter' && handleSend()} 
                disabled={loading}
                placeholder={loading ? "Waiting..." : "Type your simple answer..."} 
                className="w-full px-6 py-4 bg-slate-50 rounded-2xl outline-none border border-slate-100 focus:ring-2 focus:ring-indigo-500 focus:bg-white transition-all font-medium disabled:opacity-50" 
              />
            </div>
            <button 
              onClick={handleSend} 
              disabled={loading || !currentInput.trim()}
              className="w-14 h-14 bg-indigo-600 text-white rounded-2xl font-bold flex items-center justify-center shadow-lg shadow-indigo-100 hover:bg-indigo-700 transition-all disabled:opacity-50 active:scale-90"
            >
              <Send className="w-5 h-5" />
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

export default InterviewModule;
